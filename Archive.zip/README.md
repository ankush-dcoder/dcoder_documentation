# dcoder_documentation

> The official documentation for Dcoder, mobile coding platform.

## Development

```bash
yarn dev
yarn build
```

For more details, please head VuePress's [documentation](https://v1.vuepress.vuejs.org/).

